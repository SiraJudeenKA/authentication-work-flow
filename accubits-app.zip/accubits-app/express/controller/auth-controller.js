const User = require("../models/user");
const jwt = require("jsonwebtoken");
const redis = require('redis');
const client = redis.createClient();

/**
 * Method used to register the new user
 * @param {*} req has the requested data.
 * @param {*} res response.
 */
const register = async function (req, res) {
    if (req.body.password) {
        let newSaltAndPass = User().getSaltAndPassword(req.body.password);
        req.body.password = newSaltAndPass.password;
    };
    try {
        const response = await User.create(req.body);
        if (response)
            res.send(response);
    } catch (Err) {
        res.send(Err);
    }
}
module.exports.register = register;

/**
 * Method used to login the user.
 * @param {*} req 
 * @param {*} res 
 */
const login = async function (req, res) {
    let time = 60 * 60 * 12;
    if (req.body) {
        try {
            let user = await User.findOne({ email: req.body.email });
            if (user) {
                let checkPassword = user.verifyPassword(user.password);
                if (checkPassword) {
                    let tokenData = {
                        id: user._id,
                        name: user.name,
                        email: user.email
                    };
                    let token = jwt.sign(tokenData, 'acc2Key', {
                        expiresIn: time
                    });
                    if (token) {
                        const myDate = new Date();
                        const tokenTime = myDate.setSeconds(myDate.getSeconds() + time);
                        await User.update({ _id: user._id }, { $set: { token: token, tokenTime: tokenTime } });
                    }

                    /**  Token to store in the redis */
                    // client.on('error', (err) => console.log('Redis Client Error', err));
                    // await client.connect();
                    // let redisData = await client.set('jwt', token);
                    let data = {
                        token: token,
                        user: user
                    };
                    res.send(data);
                }
            } else {
                res.send('No such user');
            }
        } catch (err) {
            res.send(err);
        }
    }
}
module.exports.login = login;

/**
 * Method used to get the user details
 * @param {*} req has the requested data.
 * @param {*} res has the response data.
 */
const getOneUserDetails = async function (req, res) {
    if (req && req.params) {
        try {
            let userDetails = await User.findOne({ _id: req.params.id });
            res.send(userDetails);
        } catch (Err) {
            res.send(Err);
        }
    }
}
module.exports.getOneUserDetails = getOneUserDetails;

/**
 * Method used to get all the user details
 * @param {*} req has the requested data.
 * @param {*} res response.
 */
const getAllUserDetails = async function (req, res) {
    try {
        let allUserDetails = await User.find({});
        res.send(allUserDetails);
    } catch (Err) {
        res.send(Err);
    }
}
module.exports.getAllUserDetails = getAllUserDetails;
