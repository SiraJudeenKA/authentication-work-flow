var express = require('express');
var router = express.Router();
const passport = require('passport');
require('../middleware/passport')(passport);
let AuthController = require('../controller/auth-controller');

router.post('/register', AuthController.register);
router.post('/login', AuthController.login);
router.get('/userdetails/:id', passport.authenticate('jwt', { session: false }), AuthController.getOneUserDetails);
router.get('/userslogindetails', passport.authenticate('jwt', { session: false }), AuthController.getAllUserDetails);



module.exports = router;
