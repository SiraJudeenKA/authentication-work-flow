
const crypto = require("crypto");
let mongoose = require('mongoose');

const users = mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String,
        unique: true,
        required: true,
    },
    password: {
        type: String
    },

    token: { type: String },
    tokenTime: { type: Date },
},
    { timestamps: true }
);

users.methods.generateHash = function (password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

users.methods.hashPassword = function (password) {
    if (this.salt && password) {
        return crypto
            .pbkdf2Sync(password, new Buffer(this.salt, "base64"), 10000, 64, "SHA1")
            .toString("base64");
    } else {
        return password;
    }
};

users.methods.getSaltAndPassword = function (newPassword) {
    let salt = crypto.randomBytes(16).toString("base64");
    let password = crypto
        .pbkdf2Sync(newPassword, new Buffer(salt, "base64"), 10000, 64, "SHA1")
        .toString("base64");
    return { password: password };
};

//method to decrypt password
users.methods.verifyPassword = function (password) {
    let user = this;
    if (password)
        return this.password === this.hashPassword(password);
};
const User = mongoose.model('users', users);

module.exports = User;
