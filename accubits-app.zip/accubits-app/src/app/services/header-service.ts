import { Injectable } from '@angular/core';
/**
 * Class service which is used to set,get and clear the headers for specific url request.
 */
@Injectable()
export class HeaderService {
    /**
     * Variable which is used to define the header for url.
     */
    headers: { [url: string]: { [key: string]: string } } = {};
    /**
     * Method which is used to set the request headers
     * @param url define the url
     * @param key define the key
     * @param value define the value
     */
    public setHeaders(url: string, key: string, value: string) {
        // To check the headers have given url as property
        if (this.headers && this.headers.hasOwnProperty(url)) {
            this.headers[url][key] = value;
        } else {
            this.headers[url] = { [key]: value };
        }
    }
    /**
     * Method which is used to get the request headers
     * @param url define the url
     */
    public getHeaders(url: string) {
        // To check the headers have given url as property
        if (this.headers && this.headers.hasOwnProperty(url)) {
            return this.headers[url];
        } else {
            const newLocal = 'default';
            return this.headers[newLocal];
        }
    }
}
