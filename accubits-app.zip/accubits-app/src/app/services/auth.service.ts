import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { HeaderService } from './header-service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  /**
   * Constructor used to inject the serivce.
   * @param httpClient has request the api call.
   */
  constructor(private httpClient: HttpClient, private headerService: HeaderService) { }

  /**
   * Method used to make the api call for registration purpose
   * @param data has the requested data.
   * @returns response.
   */
  register(data) {
    return this.httpClient.post('http://localhost:3000/register', data);
  }

  /**
   * Method used to make the api call for login purpose
   * @param data has the requested data
   * @returns response
   */
  login(data) {
    return this.httpClient.post('http://localhost:3000/login', data).pipe(map((res: { token: string, user: {} }) => {
      if (res && res.token) {
        this.headerService.setHeaders('default', 'Authorization', res.token);
        // Define the user model structure
        return res;
      }
    }));
  }

}
