import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from 'src/app/services/auth.service';
import { RegisterConstant } from 'src/app/constants/constant';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent extends RegisterConstant implements OnInit, OnDestroy {
  /**
   * Variable is used to store the api calls subscription.
   */
  subscriptionObject: Subscription = new Subscription();
  /**
   * Variable defined the register form group.
   */
  registerForm: FormGroup;
  /**
   * Variable used to handle the password visibility purpose.
   */
  hide: boolean;
  /**
   * Variable used to handle the whether it login or Register.
   */
  isRegistration: boolean;
  /**
   * Object used to handle the details of the form.
   */
  formContent: {
    buttonName: string,
    formName: string,
    description: string
  } = {
      buttonName: this.formMessage.login,
      formName: this.formMessage.register,
      description: this.formMessage.loginDescription
    };

  /**
   * Constructor used to inject the service.
   * @param authService to make the api calls.
   * @param router to route to other components.
   * @param snackBar used to display the messages.
   */
  constructor(private authService: AuthService, private router: Router, private snackBar: MatSnackBar) {
    super();
  }

  /**
   * Life cycle hook
   */
  ngOnInit(): void {
    this.hide = true;
    this.isRegistration = false;
    this.registerForm = new FormGroup({
      email: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required)
    });
  }
  /**
   * Method used to change the form display details.
   */
  detailsChange() {
    this.isRegistration = !this.isRegistration;
    if (this.isRegistration) {
      this.registerForm.addControl('name', new FormControl(null, Validators.required));
      this.formContent = {
        buttonName: this.formMessage.register,
        formName: this.formMessage.login,
        description: this.formMessage.regiserDescription,
      };
    } else {
      this.registerForm.removeControl('name');
      this.formContent = {
        buttonName: this.formMessage.login,
        formName: this.formMessage.register,
        description: this.formMessage.loginDescription
      };
    }
  }

  /**
   * Method used to make the api call for the login or register.
   */
  registration() {
    if (this.registerForm.valid) {
      if (this.isRegistration) {
        this.subscriptionObject.add(this.authService.register(this.registerForm.value).subscribe((res) => {
          if (res) {
            this.snackBar.open(this.message.registerSuccess, '', {
              duration: 3000,
            });
          }
        }, (err) => {
          this.snackBar.open(this.message.registerFailed, '', {
            duration: 3000,
          });
        }));
      } else {
        this.subscriptionObject.add(this.authService.login(this.registerForm.value).subscribe((res) => {
          if (res) {
            this.router.navigate(['/home']);
            this.snackBar.open(this.message.loginSuccess, '', {
              duration: 3000,
            });
          }
        }, (err) => {
          this.snackBar.open(this.message.loginFailed, '', {
            duration: 3000,
          });
        }));
      }
    }
  }

  /**
   * Life cycle used to destroy the component.
   */
  ngOnDestroy(): void {
    this.subscriptionObject.unsubscribe();
  }

}
