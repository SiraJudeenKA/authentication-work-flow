export class RegisterConstant {

    /**
     * Used to display the message for the form description
     */
    formMessage = {
        login: 'Login',
        register: 'Register',
        loginDescription: 'Don`t Have an account!',
        regiserDescription: 'Already have an account!'
    };

    /**
     * Used to display the success and failure message.
     */
    message = {
        loginSuccess: 'Login Successfully!',
        loginFailed: 'Failed to login!',
        registerSuccess: 'Your account registered successfully!',
        registerFailed: 'Failed to register your account!'
    };
}
