/**
 * Interceptor class is used to intercept the all request to the api.
 */
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { HeaderService } from './services/header-service';


/**
 * Interceptor class is used to intercept the all request to the api.
 */
@Injectable()
/**
 * Interceptor class is used to intercept the all request to the api.
 */
export class TokenInterceptor implements HttpInterceptor {
    /**
     * Constructor used to inject the required services.
     * @param headerService To get headers from the header service
     * @param router used to navigate to login.
     */
    constructor(private headerService: HeaderService, private router: Router) {

    }
    /**
     * Method which is used to intercept the request.
     * @param request Which is used to define the request of the url.
     * @param next which is used to define the request passed for further processing.
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // And passed the request to the next handler and process the returned response.
        return next.handle(this.setHeaders(request)).pipe(catchError((err) => {
            if (err instanceof HttpErrorResponse && err.status === 401) {
                // If 401 error returned ,then we handle it.
                this.router.navigate(['']);
            }
            return throwError(err);
        }));
    }
    /**
     * Method which is used to set the headers for the request.
     * @param request Which is used to define the request of the url.
     */
    setHeaders(request: HttpRequest<any>) {
        // To get the headers for the given url
        const headers = this.headerService.getHeaders(request.url);
        // Add the headers to the cloned request and return it.
        return headers ? request.clone({
            setHeaders: headers
        }) : request;
    }
}
